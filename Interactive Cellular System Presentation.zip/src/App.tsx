import { useState } from 'react';

/* ── types ── */
type FrameId = 0 | 1 | 2 | 3 | 4 | 5;

interface ComponentDetail {
  title: string;
  icon: string;
  description: string;
  role: string;
  tech?: string;
}

/* ── component detail data ── */
const DETAILS: Record<string, ComponentDetail> = {
  ms: {
    title: 'Mobile Station (MS)',
    icon: '📱',
    description: "The Mobile Station is the end-user's handheld or vehicle-mounted device. It includes the Mobile Equipment (ME) and the SIM card.",
    role: 'Transmits and receives radio signals to/from the nearest BTS. Handles call setup, authentication, and cipher initiation.',
    tech: 'Operates on licensed frequency bands (e.g. 900 MHz, 1800 MHz, 2100 MHz).',
  },
  bts: {
    title: 'Base Transceiver Station (BTS)',
    icon: '📡',
    description: 'The BTS is the radio equipment located at the base of each cell tower. It forms the radio link between the mobile station and the fixed network.',
    role: 'Handles signal modulation/demodulation, frequency management, and radio channel allocation within one cell.',
    tech: 'Communicates with BSC over the Abis interface.',
  },
  bsc: {
    title: 'Base Station Controller (BSC)',
    icon: '🖥',
    description: 'The BSC is the intelligence behind the BTS. One BSC can manage several BTSs, coordinating handoffs and radio resources.',
    role: 'Manages handover between BTSs, radio frequency management, and controls the power output of mobile stations.',
    tech: 'Connects to MSC over the A interface and to BTSs over Abis.',
  },
  msc: {
    title: 'Mobile Switching Center (MSC)',
    icon: '🔄',
    description: 'The MSC is the core network element for circuit-switched calls. It routes calls between the cellular network and the PSTN or other mobile networks.',
    role: 'Handles call routing, billing, inter-MSC handovers, and interfaces with location registers (HLR/VLR).',
    tech: 'Connects to the PSTN via ISDN/SS7 signalling.',
  },
  pstn: {
    title: 'Public Switched Telephone Network (PSTN)',
    icon: '🌐',
    description: "The PSTN is the aggregate of the world's circuit-switched telephone networks. It provides connectivity to landlines and other carriers.",
    role: 'Acts as the external wired backbone that carries calls between the cellular network and the broader telephone infrastructure.',
    tech: 'Communicates using SS7 signalling and TDM transport.',
  },
  nodeB: {
    title: 'Node B (3G Base Station)',
    icon: '📡',
    description: 'Node B is the 3G equivalent of the BTS. It handles WCDMA/UMTS radio access in the UTRAN architecture.',
    role: 'Performs channel coding, spreading, and modulation over the Uu interface to mobile stations.',
    tech: 'Connects to the RNC over the Iub interface.',
  },
  rnc: {
    title: 'Radio Network Controller (RNC)',
    icon: '🖧',
    description: 'The RNC manages one or more Node Bs in UMTS. It is the 3G counterpart of the BSC.',
    role: 'Handles soft handover, radio bearer setup, and PDCP/RLC protocol layers.',
    tech: 'Connects to SGSN via Iu-PS interface and to MSC via Iu-CS.',
  },
  sgsn: {
    title: 'SGSN – Serving GPRS Support Node',
    icon: '⚙️',
    description: 'The SGSN tracks the location of mobile stations and delivers/receives data packets to/from the mobile network.',
    role: 'Handles session management, mobility management, and billing for packet-switched data services.',
    tech: 'Connects to GGSN over the Gn interface using GTP tunnel.',
  },
  ggsn: {
    title: 'GGSN – Gateway GPRS Support Node',
    icon: '🌐',
    description: 'The GGSN is the gateway between the mobile packet-switched network and external IP data networks (e.g. the Internet).',
    role: 'Performs IP address allocation, routing, and acts as the anchor point for mobile sessions.',
    tech: 'Connects to external PDN (e.g. Internet) via Gi interface.',
  },
};

/* ── small reusable atoms ── */
function NavDot({ active, onClick }: { active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${active ? 'bg-[#1a4f8a] scale-125' : 'bg-[#cbd5e1] hover:bg-[#94a3b8]'}`}
    />
  );
}

function NavButton({ onClick, children, variant = 'primary' }: { onClick: () => void; children: React.ReactNode; variant?: 'primary' | 'secondary' | 'accent' }) {
  const cls = {
    primary: 'bg-[#1a4f8a] hover:bg-[#2563b0] text-white',
    secondary: 'bg-white hover:bg-[#f1f5f9] text-[#1a4f8a] border border-[#cbd5e1]',
    accent: 'bg-[#0d9f6e] hover:bg-[#10b981] text-white',
  }[variant];
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-2 ${cls}`}
    >
      {children}
    </button>
  );
}

function Badge({ children, color = 'blue' }: { children: React.ReactNode; color?: 'blue' | 'green' | 'gray' }) {
  const cls = {
    blue: 'bg-[#dbeafe] text-[#1a4f8a]',
    green: 'bg-[#d1fae5] text-[#065f46]',
    gray: 'bg-[#f1f5f9] text-[#475569]',
  }[color];
  return <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium font-mono ${cls}`}>{children}</span>;
}

/* ── modal ── */
function DetailModal({ id, onClose }: { id: string; onClose: () => void }) {
  const d = DETAILS[id];
  if (!d) return null;
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal-card bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden border border-[#e2e8f0]"
        onClick={e => e.stopPropagation()}
      >
        <div className="bg-gradient-to-br from-[#1a4f8a] to-[#2563b0] px-6 py-5">
          <div className="text-3xl mb-2">{d.icon}</div>
          <h3 className="text-white text-lg font-semibold">{d.title}</h3>
        </div>
        <div className="px-6 py-5 space-y-4">
          <p className="text-[#475569] text-sm leading-relaxed">{d.description}</p>
          <div className="rounded-xl bg-[#f0f4f8] p-4">
            <p className="text-xs font-semibold text-[#1a4f8a] uppercase tracking-wider mb-1">Role</p>
            <p className="text-[#334155] text-sm leading-relaxed">{d.role}</p>
          </div>
          {d.tech && (
            <div className="rounded-xl bg-[#f0fdf4] p-4">
              <p className="text-xs font-semibold text-[#0d9f6e] uppercase tracking-wider mb-1">Technical Interface</p>
              <p className="text-[#334155] text-sm leading-relaxed font-mono text-xs">{d.tech}</p>
            </div>
          )}
          <button
            onClick={onClose}
            className="w-full bg-[#1a4f8a] hover:bg-[#2563b0] text-white rounded-lg py-2.5 text-sm font-medium transition-colors"
          >
            ← Back
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── clickable arch node ── */
function ArchNode({
  label, sub, icon, color = 'blue', onClick,
}: {
  label: string; sub?: string; icon?: string; color?: 'blue' | 'green' | 'gray'; onClick?: () => void;
}) {
  const border = { blue: 'border-[#bfdbfe]', green: 'border-[#a7f3d0]', gray: 'border-[#e2e8f0]' }[color];
  const bg = { blue: 'bg-[#eff6ff]', green: 'bg-[#f0fdf4]', gray: 'bg-white' }[color];
  const text = { blue: 'text-[#1a4f8a]', green: 'text-[#065f46]', gray: 'text-[#334155]' }[color];
  return (
    <button
      onClick={onClick}
      className={`${bg} ${border} border-2 rounded-xl px-5 py-3 flex flex-col items-center gap-1 text-center transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 min-w-[140px] ${onClick ? 'cursor-pointer' : 'cursor-default'}`}
    >
      {icon && <span className="text-xl">{icon}</span>}
      <span className={`font-semibold text-sm ${text}`}>{label}</span>
      {sub && <span className="text-xs text-[#64748b] font-normal">{sub}</span>}
    </button>
  );
}

/* ── downward arrow ── */
function ArrowDown({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center gap-0.5">
      {label && <span className="text-[10px] text-[#94a3b8] font-mono">{label}</span>}
      <div className="flex flex-col items-center">
        <div className="w-0.5 h-6 bg-gradient-to-b from-[#1a4f8a] to-[#93c5fd]" />
        <div
          style={{ width: 0, height: 0, borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '7px solid #1a4f8a' }}
        />
      </div>
    </div>
  );
}

function ArrowRight({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-0.5">
      {label && <span className="text-[10px] text-[#94a3b8] font-mono whitespace-nowrap">{label}</span>}
      <div className="flex items-center">
        <div className="h-0.5 w-8 bg-gradient-to-r from-[#1a4f8a] to-[#93c5fd]" />
        <div
          style={{ width: 0, height: 0, borderTop: '5px solid transparent', borderBottom: '5px solid transparent', borderLeft: '7px solid #1a4f8a' }}
        />
      </div>
    </div>
  );
}

/* ── hex cell ── */
function HexCell({ size = 64, label, active = false }: { size?: number; label?: string; active?: boolean }) {
  return (
    <div className="flex flex-col items-center gap-1.5">
      <div
        className={`hex flex items-center justify-center transition-colors ${active ? 'bg-[#1a4f8a]' : 'bg-[#dbeafe]'}`}
        style={{ width: size, height: size * 1.1 }}
      >
        <span className="text-base">📡</span>
      </div>
      {label && <span className="text-[9px] text-[#64748b] font-mono">{label}</span>}
    </div>
  );
}

/* ── frame wrapper ── */
function Frame({ children }: { children: React.ReactNode }) {
  return (
    <div className="slide-enter min-h-full">
      {children}
    </div>
  );
}

/* ── slide header ── */
function SlideHeader({ frame, title, subtitle }: { frame: number; title: string; subtitle?: string }) {
  return (
    <div className="border-b border-[#e2e8f0] bg-white px-8 py-5 flex items-center justify-between">
      <div>
        <div className="flex items-center gap-3 mb-1">
          <span className="text-xs font-mono text-[#94a3b8] uppercase tracking-widest">Frame {frame}</span>
          <span className="w-1 h-1 rounded-full bg-[#cbd5e1]" />
          <Badge color="blue">MCN-LAB</Badge>
        </div>
        <h1 className="font-display text-2xl text-[#0f172a]">{title}</h1>
        {subtitle && <p className="text-sm text-[#64748b] mt-0.5">{subtitle}</p>}
      </div>
      <div className="text-right">
        <div className="text-xs text-[#94a3b8] font-mono">Mobile Computing</div>
        <div className="text-xs text-[#94a3b8] font-mono">Laboratory Record</div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   FRAME 1 – INTRODUCTION
════════════════════════════════════════════ */
function Frame1({ goTo }: { goTo: (f: FrameId) => void }) {
  return (
    <Frame>
      <SlideHeader frame={1} title="Basic Cellular System" subtitle="Introduction to Cellular Architecture" />
      <div className="px-8 py-6 grid grid-cols-2 gap-6 h-[calc(100%-96px)]">
        {/* Left – concept */}
        <div className="space-y-5">
          <div className="bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-sm">
            <h2 className="font-semibold text-[#1a4f8a] text-base mb-3 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#1a4f8a] text-white text-xs flex items-center justify-center font-bold">!</span>
              What is a Cellular System?
            </h2>
            <ul className="space-y-3">
              {[
                ['📐', 'A cellular system divides a geographical area into smaller regions called cells.'],
                ['📡', 'Each cell is served by a Base Transceiver Station (BTS) located at or near the centre of the cell.'],
                ['📱', 'Mobile users communicate wirelessly through the cellular network by connecting to the nearest BTS.'],
              ].map(([icon, text], i) => (
                <li key={i} className="flex gap-3 items-start">
                  <span className="text-lg mt-0.5">{icon}</span>
                  <span className="text-sm text-[#334155] leading-relaxed">{text}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Hex grid visual */}
          <div className="bg-white rounded-2xl border border-[#e2e8f0] p-5 shadow-sm">
            <p className="text-xs text-[#64748b] font-mono uppercase tracking-wider mb-4">Cellular Coverage Model</p>
            <div className="flex justify-center gap-1">
              <div className="flex flex-col gap-1">
                <HexCell size={52} label="Cell A" />
                <HexCell size={52} label="Cell D" />
              </div>
              <div className="flex flex-col gap-1 mt-6">
                <HexCell size={52} label="Cell B" active />
                <HexCell size={52} label="Cell E" />
              </div>
              <div className="flex flex-col gap-1">
                <HexCell size={52} label="Cell C" />
                <HexCell size={52} label="Cell F" />
              </div>
            </div>
            <p className="text-center text-[10px] text-[#94a3b8] font-mono mt-3">Active cell highlighted — each contains a BTS</p>
          </div>
        </div>

        {/* Right – system types */}
        <div className="space-y-4">
          <p className="text-sm font-semibold text-[#475569] uppercase tracking-wider">Two Major System Types</p>

          <button
            onClick={() => goTo(2)}
            className="w-full bg-gradient-to-br from-[#1a4f8a] to-[#2563b0] text-white rounded-2xl p-5 text-left hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 border border-[#1e40af]"
          >
            <div className="text-2xl mb-2">📞</div>
            <h3 className="font-semibold text-base mb-1">Circuit-Switched System</h3>
            <p className="text-blue-200 text-sm leading-relaxed">A dedicated channel is reserved for the entire duration of a call. Used in 1G and 2G (GSM) voice networks.</p>
            <div className="mt-3 flex gap-2">
              <Badge color="blue">Analog (AMPS)</Badge>
              <Badge color="blue">Digital (GSM)</Badge>
            </div>
            <div className="mt-3 text-xs text-blue-300 font-mono">Click to explore →</div>
          </button>

          <button
            onClick={() => goTo(4)}
            className="w-full bg-gradient-to-br from-[#065f46] to-[#0d9f6e] text-white rounded-2xl p-5 text-left hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 border border-[#047857]"
          >
            <div className="text-2xl mb-2">🌐</div>
            <h3 className="font-semibold text-base mb-1">Packet-Switched System</h3>
            <p className="text-green-200 text-sm leading-relaxed">Data is broken into packets and sent over shared channels. Used in GPRS, UMTS, and LTE data networks.</p>
            <div className="mt-3 flex gap-2">
              <Badge color="green">GPRS</Badge>
              <Badge color="green">UMTS / 3G</Badge>
            </div>
            <div className="mt-3 text-xs text-green-300 font-mono">Click to explore →</div>
          </button>

          <div className="bg-white rounded-xl border border-[#e2e8f0] px-4 py-3 text-xs text-[#64748b] leading-relaxed font-mono">
            Experiment: Basic Cellular System – Components and Architecture
          </div>
        </div>
      </div>
    </Frame>
  );
}

/* ═══════════════════════════════════════════
   FRAME 2 – COMPONENTS
════════════════════════════════════════════ */
function Frame2({ goTo }: { goTo: (f: FrameId) => void }) {
  const [modal, setModal] = useState<string | null>(null);
  return (
    <Frame>
      <SlideHeader frame={2} title="Components of a Basic Cellular System" subtitle="Network Architecture Overview" />
      {modal && <DetailModal id={modal} onClose={() => setModal(null)} />}

      <div className="px-8 py-6 grid grid-cols-3 gap-6 h-[calc(100%-96px)]">
        {/* Col 1 – hex grid */}
        <div className="bg-white rounded-2xl border border-[#e2e8f0] p-5 shadow-sm flex flex-col">
          <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-4">Coverage Cells</p>
          <div className="flex-1 flex items-center justify-center">
            <div className="grid gap-1" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
              {['A1', 'A2', 'A3', 'B1', 'B2', 'B3', 'C1', 'C2', 'C3'].map((l, i) => (
                <HexCell key={l} size={44} label={l} active={i === 4} />
              ))}
            </div>
          </div>
          <div className="mt-4 space-y-2 text-xs text-[#64748b]">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 hex bg-[#1a4f8a]" />
              <span>Active BTS</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 hex bg-[#dbeafe]" />
              <span>Adjacent cells</span>
            </div>
          </div>
        </div>

        {/* Col 2 – hierarchy */}
        <div className="flex flex-col items-center justify-center gap-1">
          <ArchNode label="Mobile Station" sub="End-user device" icon="📱" color="blue" onClick={() => setModal('ms')} />
          <ArrowDown label="Air Interface" />
          <ArchNode label="BTS" sub="Base Transceiver Station" icon="📡" color="blue" onClick={() => setModal('bts')} />
          <ArrowDown label="Abis" />
          <ArchNode label="BSC" sub="Base Station Controller" icon="🖥" color="blue" onClick={() => setModal('bsc')} />
          <ArrowDown label="A Interface" />
          <ArchNode label="MSC" sub="Mobile Switching Center" icon="🔄" color="blue" onClick={() => setModal('msc')} />
          <ArrowDown label="ISDN/SS7" />
          <ArchNode label="PSTN / Wired Network" sub="External telephone system" icon="🌐" color="green" onClick={() => setModal('pstn')} />
          <p className="mt-3 text-[10px] text-[#94a3b8] font-mono text-center">Click any component to learn more</p>
        </div>

        {/* Col 3 – labels */}
        <div className="space-y-3">
          {[
            { id: 'ms',   icon: '📱', label: 'Mobile Station', desc: "User's handheld or vehicle-mounted wireless device." },
            { id: 'bts',  icon: '📡', label: 'BTS',            desc: 'Handles radio transmission within one cell.' },
            { id: 'bsc',  icon: '🖥', label: 'BSC',            desc: 'Controls multiple BTSs; manages handover.' },
            { id: 'msc',  icon: '🔄', label: 'MSC',            desc: 'Core switch for routing calls and managing mobility.' },
            { id: 'pstn', icon: '🌐', label: 'PSTN',           desc: 'External wired telephone network interconnect.' },
          ].map(({ id, icon, label, desc }) => (
            <button
              key={id}
              onClick={() => setModal(id)}
              className="w-full bg-white rounded-xl border border-[#e2e8f0] px-4 py-3 flex items-start gap-3 text-left hover:border-[#1a4f8a] hover:shadow-sm transition-all duration-150"
            >
              <span className="text-lg mt-0.5">{icon}</span>
              <div>
                <p className="font-semibold text-sm text-[#1a4f8a]">{label}</p>
                <p className="text-xs text-[#64748b] leading-relaxed mt-0.5">{desc}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </Frame>
  );
}

/* ═══════════════════════════════════════════
   FRAME 3 – ANALOG CIRCUIT-SWITCHED
════════════════════════════════════════════ */
function Frame3() {
  return (
    <Frame>
      <SlideHeader frame={3} title="Analog Circuit-Switched System" subtitle="First Generation (1G) Architecture — AMPS" />

      <div className="px-8 py-6 grid grid-cols-2 gap-6 h-[calc(100%-96px)]">
        {/* Left – diagram */}
        <div className="bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-sm flex flex-col">
          <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-6">Architecture Diagram</p>

          <div className="flex-1 flex flex-col items-center justify-center gap-2">
            {/* Mobile Unit */}
            <div className="bg-[#eff6ff] border-2 border-[#bfdbfe] rounded-xl px-8 py-4 text-center">
              <div className="text-3xl mb-1">📱</div>
              <p className="font-semibold text-[#1a4f8a] text-sm">Mobile Unit</p>
              <p className="text-xs text-[#64748b] mt-0.5">Analog handset / car phone</p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-0.5 h-8 bg-[#1a4f8a]" />
              <span className="text-[10px] font-mono text-[#94a3b8] my-0.5">Radio Channel (FDMA)</span>
              <div className="w-0.5 h-8 bg-[#1a4f8a]" />
              <div style={{ borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '7px solid #1a4f8a' }} />
            </div>

            {/* Cell Site */}
            <div className="bg-[#eff6ff] border-2 border-[#bfdbfe] rounded-xl px-8 py-4 text-center">
              <div className="text-3xl mb-1">📡</div>
              <p className="font-semibold text-[#1a4f8a] text-sm">Cell Site</p>
              <p className="text-xs text-[#64748b] mt-0.5">Base station tower</p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-0.5 h-8 bg-[#1a4f8a]" />
              <span className="text-[10px] font-mono text-[#94a3b8] my-0.5">Dedicated Trunk Line</span>
              <div className="w-0.5 h-8 bg-[#1a4f8a]" />
              <div style={{ borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '7px solid #1a4f8a' }} />
            </div>

            {/* MTSO */}
            <div className="bg-[#f0fdf4] border-2 border-[#a7f3d0] rounded-xl px-8 py-4 text-center">
              <div className="text-3xl mb-1">🏢</div>
              <p className="font-semibold text-[#065f46] text-sm">MTSO</p>
              <p className="text-xs text-[#64748b] mt-0.5">Mobile Telephone Switching Office</p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-0.5 h-6 bg-[#0d9f6e]" />
              <div style={{ borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '7px solid #0d9f6e' }} />
            </div>

            <div className="bg-[#fefce8] border border-[#fde68a] rounded-lg px-6 py-2 text-center">
              <p className="text-xs font-medium text-[#78350f]">Public Telephone Network (PSTN)</p>
            </div>
          </div>
        </div>

        {/* Right – key concepts */}
        <div className="space-y-4">
          <div className="bg-[#1a4f8a] rounded-2xl p-5 text-white">
            <h3 className="font-semibold text-base mb-2">Key Principle</h3>
            <p className="text-blue-200 text-sm leading-relaxed">
              A <span className="text-white font-medium">dedicated traffic channel</span> is maintained between the Mobile Unit and the MTSO for the entire duration of the call. No other user can share this channel while it is in use.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-[#e2e8f0] p-5 shadow-sm space-y-3">
            <h3 className="font-semibold text-[#1a4f8a] text-sm uppercase tracking-wider">Component Roles</h3>
            {[
              ['📱', 'Mobile Unit', 'Analog transceiver that initiates and receives calls. Transmits on one frequency, receives on another (FDD).'],
              ['📡', 'Cell Site', 'Receives the analog radio signal from the mobile unit and forwards it over a wired trunk to the MTSO.'],
              ['🏢', 'MTSO', 'Central switching office that routes the call, manages handoffs between cell sites, and connects to the PSTN.'],
            ].map(([icon, title, desc]) => (
              <div key={title as string} className="flex gap-3 items-start">
                <span className="text-xl">{icon}</span>
                <div>
                  <p className="font-semibold text-sm text-[#0f172a]">{title}</p>
                  <p className="text-xs text-[#64748b] leading-relaxed">{desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-[#e2e8f0] p-4 shadow-sm">
            <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-2">Technology</p>
            <div className="flex flex-wrap gap-2">
              <Badge color="blue">FDMA</Badge>
              <Badge color="blue">AMPS (US)</Badge>
              <Badge color="blue">NMT (Europe)</Badge>
              <Badge color="gray">Frequency: 800 MHz</Badge>
              <Badge color="gray">Generation: 1G</Badge>
            </div>
          </div>
        </div>
      </div>
    </Frame>
  );
}

/* ═══════════════════════════════════════════
   FRAME 4 – DIGITAL CIRCUIT-SWITCHED
════════════════════════════════════════════ */
function Frame4() {
  return (
    <Frame>
      <SlideHeader frame={4} title="Digital Circuit-Switched System" subtitle="Second Generation (2G) GSM Architecture" />

      <div className="px-8 py-6 grid grid-cols-2 gap-6 h-[calc(100%-96px)]">
        {/* Left – comm path */}
        <div className="bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-sm flex flex-col">
          <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-4">Communication Path</p>

          <div className="flex-1 flex flex-col items-center justify-center gap-1">
            {/* MS */}
            <div className="bg-[#eff6ff] border-2 border-[#1a4f8a] rounded-xl w-full max-w-xs py-3 px-5 flex items-center gap-3">
              <span className="text-2xl">📱</span>
              <div>
                <p className="font-semibold text-[#1a4f8a] text-sm">MS — Mobile Station</p>
                <p className="text-xs text-[#64748b]">SIM + Mobile Equipment</p>
              </div>
              <Badge color="blue">Um</Badge>
            </div>

            <ArrowDown label="Air Interface (TDMA/FDMA)" />

            {/* BTS */}
            <div className="bg-[#eff6ff] border-2 border-[#bfdbfe] rounded-xl w-full max-w-xs py-3 px-5 flex items-center gap-3">
              <span className="text-2xl">📡</span>
              <div>
                <p className="font-semibold text-[#1a4f8a] text-sm">BTS — Base Transceiver Station</p>
                <p className="text-xs text-[#64748b]">Radio transceiver hardware</p>
              </div>
            </div>

            <ArrowDown label="Abis Interface" />

            {/* BSC */}
            <div className="bg-[#eff6ff] border-2 border-[#bfdbfe] rounded-xl w-full max-w-xs py-3 px-5 flex items-center gap-3">
              <span className="text-2xl">🖥</span>
              <div>
                <p className="font-semibold text-[#1a4f8a] text-sm">BSC — Base Station Controller</p>
                <p className="text-xs text-[#64748b]">Manages radio resources</p>
              </div>
            </div>

            <ArrowDown label="A Interface" />

            {/* Switching Subsystem */}
            <div className="bg-[#f0fdf4] border-2 border-[#a7f3d0] rounded-xl w-full max-w-xs py-3 px-5 flex items-center gap-3">
              <span className="text-2xl">🔄</span>
              <div>
                <p className="font-semibold text-[#065f46] text-sm">Switching Subsystem (NSS)</p>
                <p className="text-xs text-[#64748b]">MSC · HLR · VLR · AuC · EIR</p>
              </div>
            </div>

            <div className="flex flex-col items-center mt-1">
              <div className="w-0.5 h-5 bg-[#0d9f6e]" />
              <div style={{ borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '7px solid #0d9f6e' }} />
            </div>

            <div className="bg-[#fefce8] border border-[#fde68a] rounded-lg w-full max-w-xs py-2 px-5 text-center">
              <p className="text-xs font-medium text-[#78350f]">PSTN / ISDN External Network</p>
            </div>
          </div>
        </div>

        {/* Right */}
        <div className="space-y-4">
          <div className="bg-[#1a4f8a] rounded-2xl p-5 text-white">
            <h3 className="font-semibold text-base mb-2">GSM Sub-systems</h3>
            <div className="space-y-2 text-sm">
              <div><span className="text-blue-300 font-mono text-xs">BSS</span><span className="text-blue-200"> — Base Station Subsystem (BTS + BSC)</span></div>
              <div><span className="text-blue-300 font-mono text-xs">NSS</span><span className="text-blue-200"> — Network Switching Subsystem</span></div>
              <div><span className="text-blue-300 font-mono text-xs">OSS</span><span className="text-blue-200"> — Operations Support Subsystem</span></div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-[#e2e8f0] p-5 shadow-sm">
            <h3 className="font-semibold text-[#1a4f8a] text-sm uppercase tracking-wider mb-3">Interfaces</h3>
            <div className="space-y-2">
              {[
                ['Um', 'MS ↔ BTS', 'Air interface — TDMA frames over 200 kHz channels'],
                ['Abis', 'BTS ↔ BSC', 'PCM links; carries traffic and signalling'],
                ['A', 'BSC ↔ MSC', 'Circuit traffic + BSSAP signalling'],
              ].map(([iface, path, desc]) => (
                <div key={iface as string} className="flex gap-3 items-start rounded-lg bg-[#f8fafc] px-3 py-2">
                  <Badge color="blue">{iface}</Badge>
                  <div>
                    <p className="font-mono text-xs text-[#1a4f8a]">{path}</p>
                    <p className="text-xs text-[#64748b] leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#e2e8f0] p-4 shadow-sm">
            <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-2">Technology</p>
            <div className="flex flex-wrap gap-2">
              <Badge color="blue">GSM</Badge>
              <Badge color="blue">TDMA</Badge>
              <Badge color="blue">IS-136</Badge>
              <Badge color="gray">Frequency: 900/1800 MHz</Badge>
              <Badge color="gray">Generation: 2G</Badge>
            </div>
          </div>

          <div className="bg-[#f0fdf4] rounded-xl border border-[#a7f3d0] p-4">
            <p className="text-xs text-[#065f46] leading-relaxed">
              <span className="font-semibold">Key difference from analog:</span> Digital encoding (speech codecs like RPE-LTP), encryption over the air interface (A5/1), and SIM-based subscriber identity.
            </p>
          </div>
        </div>
      </div>
    </Frame>
  );
}

/* ═══════════════════════════════════════════
   FRAME 5 – PACKET-SWITCHED
════════════════════════════════════════════ */
function Frame5() {
  const [modal, setModal] = useState<string | null>(null);
  const nodes = [
    { id: 'ms',   icon: '📱', label: 'MS', sub: 'Mobile Station' },
    { id: 'nodeB', icon: '📡', label: 'Node B', sub: '3G Base Station' },
    { id: 'rnc',  icon: '🖧', label: 'RNC', sub: 'Radio Network Controller' },
    { id: 'sgsn', icon: '⚙️', label: 'SGSN', sub: 'Serving GPRS Support Node' },
    { id: 'ggsn', icon: '🌐', label: 'GGSN', sub: 'Gateway GPRS Support Node' },
  ];
  return (
    <Frame>
      <SlideHeader frame={5} title="Packet-Switched Cellular System" subtitle="UMTS / 3G GPRS Packet Data Architecture" />
      {modal && <DetailModal id={modal} onClose={() => setModal(null)} />}

      <div className="px-8 py-6 grid grid-cols-2 gap-6 h-[calc(100%-96px)]">
        {/* Left – flow diagram */}
        <div className="bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-sm flex flex-col">
          <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-5">Packet Flow Diagram</p>

          <div className="flex-1 flex flex-col items-center justify-center gap-1.5">
            {nodes.map((node, i) => (
              <div key={node.id} className="flex flex-col items-center gap-1.5 w-full">
                <button
                  onClick={() => setModal(node.id)}
                  className="bg-[#eff6ff] border-2 border-[#bfdbfe] hover:border-[#1a4f8a] rounded-xl w-full max-w-xs py-3 px-5 flex items-center gap-3 transition-all duration-150 hover:shadow-sm"
                >
                  <span className="text-2xl">{node.icon}</span>
                  <div className="text-left">
                    <p className="font-semibold text-[#1a4f8a] text-sm">{node.label}</p>
                    <p className="text-xs text-[#64748b]">{node.sub}</p>
                  </div>
                </button>
                {i < nodes.length - 1 && (
                  <div className="flex flex-col items-center">
                    <div className="w-0.5 h-4 bg-[#0d9f6e]" />
                    <div style={{ borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '7px solid #0d9f6e' }} />
                  </div>
                )}
              </div>
            ))}

            <div className="flex flex-col items-center gap-1 mt-1">
              <div className="w-0.5 h-4 bg-[#0d9f6e]" />
              <div style={{ borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '7px solid #0d9f6e' }} />
            </div>

            <div className="bg-[#fefce8] border border-[#fde68a] rounded-lg w-full max-w-xs py-2 px-5 text-center">
              <p className="text-xs font-medium text-[#78350f]">External IP Network / Internet</p>
            </div>
            <p className="text-[10px] text-[#94a3b8] font-mono text-center mt-1">Click any node to learn more</p>
          </div>
        </div>

        {/* Right */}
        <div className="space-y-4">
          <div className="bg-[#065f46] rounded-2xl p-5 text-white">
            <h3 className="font-semibold text-base mb-2">Key Principle</h3>
            <p className="text-green-200 text-sm leading-relaxed">
              Data is divided into <span className="text-white font-medium">packets</span> and sent over shared radio channels. Resources are allocated only when data is being transmitted — no dedicated channel is maintained for the full session.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-[#e2e8f0] p-5 shadow-sm space-y-3">
            <h3 className="font-semibold text-[#1a4f8a] text-sm uppercase tracking-wider">Protocol Stack</h3>
            {[
              ['Uu', 'MS ↔ Node B', 'WCDMA air interface'],
              ['Iub', 'Node B ↔ RNC', 'ATM / IP transport'],
              ['Iu-PS', 'RNC ↔ SGSN', 'GTP-U / GTP-C tunnels'],
              ['Gn', 'SGSN ↔ GGSN', 'GTP tunnel (internal PDN)'],
              ['Gi', 'GGSN ↔ Internet', 'Standard IP routing'],
            ].map(([iface, path, desc]) => (
              <div key={iface as string} className="flex gap-3 items-start rounded-lg bg-[#f0fdf4] px-3 py-2">
                <Badge color="green">{iface}</Badge>
                <div>
                  <p className="font-mono text-xs text-[#065f46]">{path}</p>
                  <p className="text-xs text-[#64748b]">{desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-[#e2e8f0] p-4 shadow-sm">
            <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-2">Technology</p>
            <div className="flex flex-wrap gap-2">
              <Badge color="green">UMTS</Badge>
              <Badge color="green">WCDMA</Badge>
              <Badge color="green">GPRS</Badge>
              <Badge color="gray">Frequency: 2100 MHz</Badge>
              <Badge color="gray">Generation: 3G</Badge>
            </div>
          </div>
        </div>
      </div>
    </Frame>
  );
}

/* ═══════════════════════════════════════════
   FRAME 6 – SUMMARY
════════════════════════════════════════════ */
function Frame6() {
  return (
    <Frame>
      <SlideHeader frame={6} title="Basic Cellular System — Summary" subtitle="Consolidated Architecture Reference" />

      <div className="px-8 py-6 space-y-5 h-[calc(100%-96px)] overflow-y-auto">
        {/* End-to-end path */}
        <div className="bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-sm">
          <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-5">Complete Communication Path</p>
          <div className="flex items-center justify-center flex-wrap gap-2">
            {[
              { icon: '📱', label: 'Mobile Station' },
              { icon: '📡', label: 'BTS' },
              { icon: '🖥', label: 'BSC' },
              { icon: '🔄', label: 'MSC' },
              { icon: '🌐', label: 'External Network' },
            ].map((node, i, arr) => (
              <div key={node.label} className="flex items-center gap-2">
                <div className="bg-[#eff6ff] border-2 border-[#bfdbfe] rounded-xl px-4 py-3 flex flex-col items-center gap-1 min-w-[96px]">
                  <span className="text-2xl">{node.icon}</span>
                  <span className="text-xs font-semibold text-[#1a4f8a] text-center">{node.label}</span>
                </div>
                {i < arr.length - 1 && (
                  <div className="flex items-center">
                    <div className="h-0.5 w-5 bg-[#1a4f8a]" />
                    <div style={{ borderTop: '4px solid transparent', borderBottom: '4px solid transparent', borderLeft: '6px solid #1a4f8a' }} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Summary statement */}
        <div className="bg-gradient-to-br from-[#1a4f8a] to-[#2563b0] rounded-2xl p-6 text-white">
          <p className="font-display text-xl leading-relaxed italic">
            "A cellular system provides wireless communication by dividing a geographical area into cells and connecting mobile stations through base stations and switching/network components."
          </p>
        </div>

        {/* Comparison table */}
        <div className="bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-sm">
          <p className="text-xs font-mono text-[#94a3b8] uppercase tracking-wider mb-4">System Comparison</p>
          <div className="grid grid-cols-4 gap-0 text-sm rounded-xl overflow-hidden border border-[#e2e8f0]">
            {['Feature', 'Analog (1G)', 'Digital Circuit (2G)', 'Packet (3G/GPRS)'].map(h => (
              <div key={h} className="bg-[#1a4f8a] text-white px-4 py-2.5 font-semibold text-xs">{h}</div>
            ))}
            {[
              ['Multiple Access', 'FDMA', 'TDMA / CDMA', 'WCDMA'],
              ['Signal Type', 'Analog FM', 'Digital (PCM)', 'Digital IP Packets'],
              ['Data Support', 'None', 'Limited (CSD)', 'Full (packet data)'],
              ['Handset Example', 'Car phone', 'GSM mobile', 'UMTS smartphone'],
              ['Generation', '1G', '2G', '3G'],
            ].map((row, ri) => (
              row.map((cell, ci) => (
                <div
                  key={`${ri}-${ci}`}
                  className={`px-4 py-2.5 text-xs border-t border-[#e2e8f0] ${ri % 2 === 0 ? 'bg-[#f8fafc]' : 'bg-white'} ${ci === 0 ? 'font-medium text-[#475569]' : 'text-[#334155]'}`}
                >
                  {cell}
                </div>
              ))
            ))}
          </div>
        </div>

        {/* Key takeaways */}
        <div className="grid grid-cols-3 gap-4">
          {[
            { color: 'blue', icon: '📐', title: 'Cell Structure', desc: 'Hexagonal cells allow frequency reuse while minimising interference between adjacent cells.' },
            { color: 'green', icon: '🔄', title: 'Handover', desc: 'MSC/BSC manages seamless handover of calls between cells as the user moves across coverage areas.' },
            { color: 'gray', icon: '📶', title: 'Frequency Reuse', desc: 'Cells far enough apart can reuse the same frequencies, dramatically increasing network capacity.' },
          ].map(({ color, icon, title, desc }) => (
            <div
              key={title}
              className={`rounded-xl p-4 border ${color === 'blue' ? 'bg-[#eff6ff] border-[#bfdbfe]' : color === 'green' ? 'bg-[#f0fdf4] border-[#a7f3d0]' : 'bg-white border-[#e2e8f0]'}`}
            >
              <span className="text-2xl">{icon}</span>
              <p className={`font-semibold text-sm mt-2 mb-1 ${color === 'blue' ? 'text-[#1a4f8a]' : color === 'green' ? 'text-[#065f46]' : 'text-[#334155]'}`}>{title}</p>
              <p className="text-xs text-[#64748b] leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </Frame>
  );
}

/* ═══════════════════════════════════════════
   MAIN APP
════════════════════════════════════════════ */
const FRAMES = [
  { label: 'Introduction',              short: '01' },
  { label: 'Components',                short: '02' },
  { label: 'Analog Circuit-Switched',   short: '03' },
  { label: 'Digital Circuit-Switched',  short: '04' },
  { label: 'Packet-Switched',           short: '05' },
  { label: 'Summary',                   short: '06' },
];

export default function App() {
  const [frame, setFrame] = useState<FrameId>(0);

  const goTo = (f: FrameId) => setFrame(f);
  const prev = () => setFrame(f => Math.max(0, f - 1) as FrameId);
  const next = () => setFrame(f => Math.min(5, f + 1) as FrameId);

  const content = [
    <Frame1 key={0} goTo={goTo} />,
    <Frame2 key={1} goTo={goTo} />,
    <Frame3 key={2} />,
    <Frame4 key={3} />,
    <Frame5 key={4} />,
    <Frame6 key={5} />,
  ][frame];

  return (
    <div className="min-h-screen flex flex-col bg-[#e8edf3]">
      {/* Top bar */}
      <header className="bg-[#0f172a] text-white px-6 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-[#0d9f6e]" />
          <span className="font-mono text-xs text-slate-400 uppercase tracking-widest">Mobile Computing Lab</span>
          <span className="text-slate-600">·</span>
          <span className="font-mono text-xs text-slate-300">Basic Cellular System</span>
        </div>
        <div className="flex items-center gap-2">
          {FRAMES.map((f, i) => (
            <button
              key={i}
              onClick={() => goTo(i as FrameId)}
              className={`font-mono text-[10px] px-2.5 py-1 rounded-md transition-colors ${frame === i ? 'bg-[#1a4f8a] text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700'}`}
            >
              {f.short}
            </button>
          ))}
        </div>
      </header>

      {/* Slide area */}
      <main className="flex-1 overflow-hidden bg-white shadow-xl mx-4 my-4 rounded-2xl border border-[#e2e8f0] overflow-y-auto">
        <div key={frame}>
          {content}
        </div>
      </main>

      {/* Bottom nav */}
      <footer className="shrink-0 px-6 py-3 flex items-center justify-between bg-[#e8edf3]">
        <NavButton onClick={prev} variant="secondary">
          ← Previous
        </NavButton>

        <div className="flex items-center gap-3">
          {FRAMES.map((_, i) => (
            <NavDot key={i} active={frame === i} onClick={() => goTo(i as FrameId)} />
          ))}
          <span className="ml-2 text-xs text-[#94a3b8] font-mono">{frame + 1} / {FRAMES.length}</span>
        </div>

        <div className="flex items-center gap-2">
          {frame === 0 && (
            <>
              <NavButton onClick={() => goTo(2)} variant="primary">📞 Circuit Switched</NavButton>
              <NavButton onClick={() => goTo(4)} variant="accent">🌐 Packet Switched</NavButton>
            </>
          )}
          {frame !== 0 && (
            <NavButton onClick={() => goTo(0)} variant="secondary">🏠 Home</NavButton>
          )}
          <NavButton onClick={next} variant="primary">
            Next →
          </NavButton>
        </div>
      </footer>
    </div>
  );
}
